# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Contributed to by:
# fluiddesigner, Pontiac, Fourmadmen, varkenvarken, tuga3d, meta-androcto, metalliandy     #
# dreampainter, cotejrp1, liero, Kayo Phoenix, sugiany, dommetysk, Jambay   #
# Phymec, Anthony D'Agostino, Pablo Vazquez, Richard Wilks, lijenstina,     #
# Sjaak-de-Draak, Phil Cote, cotejrp1, xyz presets by elfnor, revolt_randy, #


bl_info = {
    "name": "FD Parametric Meshes",
    "author": "fluiddesigner + Multiple Authors",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Mesh",
    "description": "Add extra paramteric mesh object types",
    "warning": "",
    "wiki_url": "https://www.fluiddesigner.co.uk/",
    "category": "Add Mesh",
}


if "bpy" in locals():
    import importlib
    importlib.reload(add_mesh_fd3d_astroidal_ellipsoid)
    importlib.reload(add_mesh_fd3d_bohemian_barrel)
    importlib.reload(add_mesh_fd3d_bohemian_dome)
    importlib.reload(add_mesh_fd3d_boy_surface)
    importlib.reload(add_mesh_fd3d_cornucopia_surface)
    importlib.reload(add_mesh_fd3d_crosscap_surface)
    importlib.reload(add_mesh_fd3d_dingdong_surface)
    importlib.reload(add_mesh_fd3d_eight_surface)
    importlib.reload(add_mesh_fd3d_elliptic_hyperboloid)
    importlib.reload(add_mesh_fd3d_enneper_surface)
    importlib.reload(add_mesh_fd3d_henneberg_surface)
    importlib.reload(add_mesh_fd3d_horn_torus)
    importlib.reload(add_mesh_fd3d_roman_surface)
    importlib.reload(add_mesh_fd3d_sine_surface)
    importlib.reload(add_mesh_fd3d_whitney_umbrella)

else:
    from . import add_mesh_fd3d_astroidal_ellipsoid
    from . import add_mesh_fd3d_bohemian_barrel
    from . import add_mesh_fd3d_bohemian_dome
    from . import add_mesh_fd3d_boy_surface
    from . import add_mesh_fd3d_cornucopia_surface
    from . import add_mesh_fd3d_crosscap_surface
    from . import add_mesh_fd3d_dingdong_surface
    from . import add_mesh_fd3d_eight_surface
    from . import add_mesh_fd3d_elliptic_hyperboloid
    from . import add_mesh_fd3d_enneper_surface
    from . import add_mesh_fd3d_henneberg_surface
    from . import add_mesh_fd3d_horn_torus
    from . import add_mesh_fd3d_roman_surface
    from . import add_mesh_fd3d_sine_surface
    from . import add_mesh_fd3d_whitney_umbrella    

import bpy
from bpy.types import Menu


class VIEW3D_MT_fdmesh_maths_add(Menu):
    # Define the "Math Function" menu
    bl_idname = "VIEW3D_MT_fdmesh_maths_add"
    bl_label = "FD Parametric Meshes"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.operator("mesh.primitive_xyz_astroidal_ellipsoid", text="Astroidal Ellipsoid")
        layout.operator("mesh.primitive_xyz_bohemian_barrel", text="Bohemian Barrel")
        layout.operator("mesh.primitive_xyz_bohemian_dome", text="Bohemian Dome")
        layout.operator("mesh.primitive_xyz_boy_surface", text="Boy Surface")
        layout.operator("mesh.primitive_xyz_cornucopia_surface", text="Cornucopia Surface")
        layout.operator("mesh.primitive_xyz_crosscap_surface", text="CrossCap Surface")
        layout.operator("mesh.primitive_xyz_dingdong_surface", text="DingDong Surface")
        layout.operator("mesh.primitive_xyz_eight_surface", text="Eight Surface")
        layout.operator("mesh.primitive_xyz_elliptic_hyperboloid", text="Elliptic Hyperboloid")
        layout.operator("mesh.primitive_xyz_enneper_surface", text="Enneper Surface")
        layout.operator("mesh.primitive_xyz_henneberg_surface", text="Henneberg Surface")
        layout.operator("mesh.primitive_xyz_horn_torus", text="Horn Torus")
        layout.operator("mesh.primitive_xyz_roman_surface", text="Roman Surface")
        layout.operator("mesh.primitive_xyz_sine_surface", text="Sine Surface")
        layout.operator("mesh.primitive_xyz_whitney_umbrella", text="Whitney Umbrella")



class VIEW3D_MT_mesh_extras_add(Menu):
    # Define the "Extra Objects" menu
    bl_idname = "VIEW3D_MT_mesh_extras_add"
    bl_label = "Extras"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'

# Register all operators and panels

# Define "Extras" menu
def menu_func(self, context):
    lay_out = self.layout
    lay_out.operator_context = 'INVOKE_REGION_WIN'

    lay_out.separator()
    lay_out.menu("VIEW3D_MT_fdmesh_maths_add",
                text="FD Parametric Meshes", icon="PACKAGE")

# Register
classes = [
    VIEW3D_MT_fdmesh_maths_add,
    add_mesh_fd3d_astroidal_ellipsoid.AddXYZFDAstroidalEllipsoid,
    add_mesh_fd3d_bohemian_barrel.AddXYZFDBohemianBarrel,
    add_mesh_fd3d_bohemian_dome.AddXYZFDBohemianDome,
    add_mesh_fd3d_boy_surface.AddXYZFDBoySurface,
    add_mesh_fd3d_cornucopia_surface.AddXYZFDCornucopiaSurface,
    add_mesh_fd3d_crosscap_surface.AddXYZFDCrossCapSurface,
    add_mesh_fd3d_dingdong_surface.AddXYZFDDingDongSurface,
    add_mesh_fd3d_eight_surface.AddXYZFDEightSurface,
    add_mesh_fd3d_elliptic_hyperboloid.AddXYZFDEllipticHyperboloid,
    add_mesh_fd3d_enneper_surface.AddXYZFDEnneperSurface,
    add_mesh_fd3d_henneberg_surface.AddXYZFDHennebergSurface,
    add_mesh_fd3d_horn_torus.AddXYZFDHornTorus,
    add_mesh_fd3d_roman_surface.AddXYZFDRomanSurface,
    add_mesh_fd3d_sine_surface.AddXYZFDSineSurface,
    add_mesh_fd3d_whitney_umbrella.AddXYZFDWhitneyUmbrella,
]

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    # Add "Extras" menu to the "Add Mesh" menu and context menu.
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)


def unregister():
    # Remove "Extras" menu from the "Add Mesh" menu and context menu.
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()
